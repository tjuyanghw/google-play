  # -*- coding: utf-8 -*-
import scrapy
import time
import urlparse
import sys

from scrapy.spiders import CrawlSpider, Rule
from googleCrawl.items import GoogleItem
# from selenium import webdriver
# from selenium.common.exceptions import NoSuchElementException


class GoogleSpider(CrawlSpider):

    sys.setdefaultencoding('utf-8')
    name = "test"
    allowed_domains = ["https://play.google.com/store/apps"]

    start_urls = (
        'https://play.google.com/store/apps',


    )
    # rules = [
    #         Rule(LanguageLinkExtractor(allow=("/store/apps/details", )), callback='parse_app',follow=True),
    #     ] #

    # def __init__(self):
    #     pass
    #
    # def start_requests(self):
    #
    #     urls = [
    #         'http://quotes.toscrape.com/page/1/',
    #         'http://quotes.toscrape.com/page/2/',
    #     ]
    #     for url in urls:
    #         yield scrapy.Request(url=url, callback=self.parse)

    def parse_app(self, response):

        #item = GoogleItem()
        url = response.url
        self.driver.get(url)
        # url = urlparse.urlparse(url).query.split('&')[0].split('=')[-1]
        cat =response.xpath('//div[@id="action-dropdown-children-Categories"]/div/ul/text')
        with open('./app_id.txt', 'a+', encoding="utf-8") as f:
            f.write(str(cat) + '\n')
        # item['url'] = url
        # # item['title'] = response.xpath('//*[@id="fcxH9b"]//h1[@class="AHFaub"]/span/text()').extract()[0]
        # item["privacy_policy"] = response.xpath('//div[contains(text(),"Developer")]/..//a[contains(text(),"Privacy Policy")]/@href').extract()
        # item["privacy_policy"] = item["privacy_policy"][0] if (len(item["privacy_policy"]) > 0) else ""










