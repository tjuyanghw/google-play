  # -*- CODING: UTF-8 -*-
import scrapy
import time
import urlparse
import sys
import json
import MySQLdb
import MySQLdb.cursors
import pycld2 as cld2
from scrapy.spiders import CrawlSpider, Rule
from googleCrawl.items import GoogleItem
from selenium import webdriver


from selenium.common.exceptions import NoSuchElementException




class GoogleSpider(CrawlSpider):
    reload(sys)
    sys.setdefaultencoding('utf-8')
    name = "review"
    allowed_domains = ["play.google.com"]

    # start_urls = (
    #     'http://play.google.com/',
    #     # 'https://play.google.com/store/apps/category/FOOD_AND_DRINK'
    #     'https://play.google.com/store/apps/details?id=com.android.chrome'
    #
    # )
    # rules = [
    #         Rule(LanguageLinkExtractor(allow=("/store/apps/details", )), callback='parse_app',follow=True),
    #     ] #

    def __init__(self):
        # firefox_profile = webdriver.FirefoxProfile()
        # firefox_profile.set_preference("permissions.default.image",2)
        # firefox_profile.set_preference("int1.accept_language", "en-GB")
        # firefox_profile.update_preferences()
        # self.driver = webdriver.Firefox(firefox_profile)
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument('lang=en-GB')
        prefs = {"profile.managed_default_content_settings.images":2, "int1.accept_language": "en-GB"}
        chrome_options.add_experimental_option('prefs',prefs)
        self.driver = webdriver.Chrome(chrome_options = chrome_options)


    def start_requests(self):
        # file = open("F:\Documents\Project\googleplay_crawl\set\gplay_url.txt", "rb")

        # url = linecache.getline(r'F:\Documents\Project\googleplay_crawl\set\gplay_url.txt',10)
        urls = []
        with open('F:\Documents\Project\googleplay_crawl\set\url.txt') as rfile:
            for f in rfile:
                # f = f.replace("\"", "")
                url = 'https://play.google.com/store/apps/details?id='+ f.strip() + '&showAllReviews=true&hl=en'
                urls.append(url)


        for ele in range(0, 30000):
            if ele % 5000 == 0:
                time.sleep(3)
            yield scrapy.Request(url=urls[ele], callback=self.parse_review)
            # yield scrapy.Request(url='https://play.google.com/store/apps/details?id=com.goethe.ar&hl=en&showAllReviews=true', callback=self.parse_review)


    def parse_review(self, response):

        item = GoogleItem()

        url = response.url
        self.driver.get(url)
        url = urlparse.urlparse(url).query.split('&')[0].split('=')[-1]

        review_element_list = self.driver.find_elements_by_xpath('//div[@jsname="fk8dgd"]//div[@jscontroller="H6eOGe"]//span[@jsname="bN97Pc"]')
        if len(review_element_list) > 0:

            for i in range(0, 5):

                js="var q=document.documentElement.scrollTop=100000"
                self.driver.execute_script(js)
                time.sleep(2)


            try:
                show_more = self.driver.find_element_by_xpath('//span[contains(text(),"Show More")]')
                flag = True
            except:
                show_more = ""
                flag = False

            while(flag):
                time.sleep(3)
                show_more.click()
                for i in range(0, 5):
                    js="var q=document.documentElement.scrollTop=100000"
                    self.driver.execute_script(js)
                    time.sleep(2)
                    try:
                        show_more = self.driver.find_element_by_xpath('//span[contains(text(),"Show More")]')
                        flag = True
                    except:
                        flag = False


            review_list = []
            review_element_list = self.driver.find_elements_by_css_selector('div[jsname="fk8dgd"] > div[jscontroller="H6eOGe"] > *')

            # review_element_list = self.driver.find_elements_by_xpath('//div[@jsname="fk8dgd"]')
            for element in review_element_list:
                s = dict()
                s['user'] = element.find_element_by_css_selector('span.X43Kjb').text.strip()
                s['star'] = len(element.find_elements_by_css_selector('div[class="vQHuPe bUWb7c"]'))
                s['time'] = element.find_element_by_css_selector('span.p2TkOb').text.strip()
                s['support'] = element.find_element_by_css_selector('div[class="jUL89d y92BAb"]').text.strip()
                if len(s['support']) == 0:
                    s['support'] = '0'
                s['str'] = element.find_element_by_css_selector('span[jsname="bN97Pc"]').text.strip()


                try:
                    isReliable, textBytesFound, details = cld2.detect(s['str'])
                    if details[0][0]=="ENGLISH" and details[0][2]>95:
                        try:
                            str=s['str'].encode('utf-8')
                        except:
                            s['str']=''
                except:
                    s['str']=''



                s = json.dumps(s)

                review_list.append(s)
        else:
            review_list = ""


        item['review'] = review_list
        item['url'] = url

        # print (item['review'])
        yield item







